### Hexlet tests and linter status:
[![Actions Status](https://github.com/StanislavOkopnyi/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/StanislavOkopnyi/python-project-49/actions)

<a href="https://codeclimate.com/github/StanislavOkopnyi/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/d6d71bf38d4aa1f89148/maintainability" /></a>


### [Установка и запуск brain-even. Победа и поражение игрока](https://asciinema.org/a/F7gZxyMC02InzQvbVn56Qzaxs)
